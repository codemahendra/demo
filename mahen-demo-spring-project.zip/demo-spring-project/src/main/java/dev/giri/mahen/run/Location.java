package dev.giri.mahen.run;

public enum Location {
    INDOOR, OUTDOOR
}
