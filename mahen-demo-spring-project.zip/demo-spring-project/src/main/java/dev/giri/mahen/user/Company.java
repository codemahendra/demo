package dev.giri.mahen.user;

public record Company(
        String name,
        String catchPhrase,
        String bs
) {
}
