package dev.giri.mahen.user;

public record Geo(
        String lat,
        String lng
) {
}
